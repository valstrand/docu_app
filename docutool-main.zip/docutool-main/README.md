# docutool
AI-powered documentation tool using screen recording and AI
